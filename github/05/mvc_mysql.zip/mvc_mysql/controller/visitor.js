const visitor = require('../model/visitor');

exports.main = (req, res) => {
    res.render('index');
};

exports.getVisitors = (req, res) => {
    //getVisitors() 는 모델에서 가져온 데이터다.
    res.render('visitor', visitor.getVisitors());
};
