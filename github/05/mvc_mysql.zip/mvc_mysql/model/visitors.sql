CREATE TABLE visitor (
    id VARCHAR(10) NOT NULL PRIMARY KEY,
    name VARCHAR(10) NOT NULL,
    comment VARCHAR(20),
)

INSERT INTO visitor (id, name, comment) VALUES
('1', '홍길동', '내가 왔다.'),
('2', '이찬혁', '으라차차'),
