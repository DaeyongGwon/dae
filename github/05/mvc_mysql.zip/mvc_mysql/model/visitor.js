exports.getVisitors = () => {
    return [
        { id: 1, name: '홍길동1', comment: '내가왔다1.' },
        { id: 2, name: '홍길동2', comment: '내가왔다2.' },
        { id: 3, name: '홍길동3', comment: '내가왔다3.' },
    ];
};
