const user = require('../model/muser');

exports.main = (req, res) => {
    res.render('index');
};

//회원가입
exports.getSignup = (req, res) => {
    res.render('signup');
};

//login
exports.getLogin = (req, res) => {
    res.render('login');
};
//profile
exports.getProfile = (req, res, next) => {
    const user = req.session.user;
    if (user) {
        user.findOne({ userId: user.userId }, (err, user) => {
            if (err) {
                console.error(err);
                return next(err);
            }
            res.render('profile', { user });
        });
    } else {
        res.render('profile', { user: null });
    }
};
exports.postSignup = (req, res) => {
    const { name, userId, password } = req.body;
    console.log(req.body);
    user.signup(name, userId, password, (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            console.log(result);
            res.render('signup', { data: { name: name, userId: userId, password: password } });
        }
    });
};

exports.postLogin = (req, res) => {
    const { userId, password } = req.body;
    console.log(req.body);
    user.login(userId, password, (result) => {
        console.log(result);
        console.log('abc');
        res.send({ result: true, userId: userId, password: password });
    });
};

//수정
exports.patchProfileEdit = (req, res) => {
    const { name, userId, password } = req.body;
    console.log(req.body);
    user.edit(name, userId, password, (result) => {
        console.log(result);
        res.send({ result: true, name: name, userId: userId, password: password });
    });
};
//삭제
exports.deleteProfile = (req, res) => {
    user.deleteProfile(req.body.id, (value) => {
        res.send({ result: true, value });
    });
};
